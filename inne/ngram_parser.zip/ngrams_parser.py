#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function, division
from abc import ABCMeta, abstractmethod
import pandas as pd
import numpy as np

class Ngram(object):
    def __init__(self, name, freq):
        super(Ngram, self).__init__()
        self.name = name.decode('utf-8').strip('^')
        self.freq = float(freq)
        self.type = self._get_type(name)

    def __str__(self):
        return '({}, {})'.format(self.name, self.freq, self.type)

    def __repr__(self):
        return repr((self.name, self.freq, self.type))

    def _get_type(self, name):
        if name.find('^') == 0:
            return 'start_ngrams'
        elif name.find('^') == -1:
            return 'ngram_stop'
        else:
            return 'ngram_middle'

    def get_name(self):
        return self.name

    def get_freq(self):
        return self.freq

    def get_type(self):
        return self.type


class NgramsParser(object):
    __metaclass__ = ABCMeta

    def __init__(self, file_middle_ngrams, file_edge_ngrams, csv_delimiter='\t'):
        self.parse_data(file_middle_ngrams, file_edge_ngrams, csv_delimiter)

    def parse_data(self, file_middle_ngrams, file_edge_ngrams, csv_delimiter):
        self.middle_ngrams = self._parse_middle_engdams(file_middle_ngrams, csv_delimiter)
        self.start_ngrams, self.stop_ngrams = self._parse_edge_ngrams(file_edge_ngrams, csv_delimiter)

    def _sorted(self, ngrams):
        return sorted(ngrams, key=lambda ngram: ngram.freq, reverse=True)

    def _parse_middle_engdams(self, file_name, csv_delimiter):
        df = pd.read_csv(file_name, csv_delimiter)
        ngrams = self._sorted([Ngram(ngram,freq) for ngram,freq in zip(df.ngram,df.freq) if (not '^' in str(ngram) and  len(set('1234567890') & set(ngram)) == 0)])
        return self._sorted(ngrams)

    def _parse_edge_ngrams(self, file_name, csv_delimiter):
        df = pd.read_csv(file_name, csv_delimiter)
        start_ngrams, stop_ngrams = [], []
        for ngram, freq in zip(df.ngram, df.freq):
            if str(ngram).count('^') == 1 and len(set('1234567890') & set(ngram)) == 0:
                if ngram.find('^') == 0:
                    start_ngrams.append(Ngram(ngram, freq))
                elif ngram.find('^') in [2,4]:
                    stop_ngrams.append(Ngram(ngram, freq))
        return self._sorted(start_ngrams), self._sorted(stop_ngrams)

    def _get_freq_ngrams(self, lower, upper, ngrams):
        freq = [ngram.freq for ngram in ngrams]
        per_lower = np.percentile(freq,lower)
        per_upper = np.percentile(freq,upper)
        lower_ngram = [ngram for ngram in ngrams if ngram.freq < per_lower]
        middle_ngram = [ngram for ngram in ngrams if ngram.freq > per_lower and ngram.freq < per_upper]
        upper_ngram = [ngram for ngram in ngrams if ngram.freq > per_upper]
        return lower_ngram, middle_ngram, upper_ngram

    @abstractmethod
    def get_ngrams(self):
        pass

    @abstractmethod
    def get_freq_ngrams(self, lower, upper):
        pass

class BigramsParser(NgramsParser):
    def __init__(self, file_middle_ngrams, file_ngrams):
        super(BigramsParser, self).__init__(file_middle_ngrams, file_ngrams)

    def get_ngrams(self, type):
        if type=='start':
            return self.start_ngrams
        elif type=='stop':
            return self.stop_ngrams
        elif type=='middle':
            return self.middle_ngrams

    def get_freq_ngrams(self, lower, upper, type):
        if type=='start':
            return self._get_freq_ngrams(lower, upper, self.start_ngrams)
        elif type=='stop':
            return self._get_freq_ngrams(lower, upper, self.stop_ngrams)
        elif type=='middle':
            return self._get_freq_ngrams(lower, upper, self.middle_ngrams)

class QuadrigramsParser(NgramsParser):
    def __init__(self, file_middle_ngrams, file_ngrams):
        super(QuadrigramsParser, self).__init__(file_middle_ngrams, file_ngrams)

    def get_ngrams(self):
        return self._sorted(self.start_ngrams+self.stop_ngrams+self.middle_ngrams)

    def get_freq_ngrams(self, lower, upper):
        return self._get_freq_ngrams(lower, upper, self._sorted(self.start_ngrams+self.stop_ngrams+self.middle_ngrams))

class UnigramsParser(object):
    def __init__(self, file_unigrams, csv_delimiter='\t'):
        self.parse_data(file_unigrams, csv_delimiter='\t')
    
    def parse_data(self, file_unigrams, csv_delimiter='\t'):
        df = pd.read_csv(file_unigrams, csv_delimiter)
        self.unigrams = self._sorted([Ngram(ngram,freq) for ngram,freq in zip(df.ngram,df.freq) if not ngram.isdigit()]) 

    def _sorted(self, ngrams):
        return sorted(ngrams, key=lambda ngram: ngram.freq, reverse=True)

    def get_unigrams(self):
        return self.unigrams

    def get_freq_unigrams(self, threshold_freq='', treshold_letter='', type_ ='lower'):
        if threshold_freq != '':
            if type_ == 'upper':
                freq = [unigram.freq for unigram in self.unigrams]
                per_upper = np.percentile(freq,threshold_freq)
                return [unigram for unigram in self.unigrams if unigram.freq > per_upper]
            elif type_ == 'lower':
                freq = [unigrams.freq for unigrams in self.unigrams]
                per_lower = np.percentile(freq,threshold_freq)
                return [unigram for unigram in self.unigrams if unigram.freq < per_lower]
            else:
                raise Exception("Error: not specified the type of threshold")
        elif treshold_letter != '':
            if type_ == 'upper':
                letters = [unigram.name for unigram in self.unigrams]
                to_letter = letters.index(treshold_letter)
                return self.unigrams[:to_letter+1]
            elif type_ == 'lower':
                letters = [unigram.name for unigram in self.unigrams]
                from_letter = letters.index(treshold_letter)
                return self.unigrams[from_letter:]
            else:
                raise Exception("Error: not specified the type of threshold")
        else:
            raise Exception("Error: not specified the threshold")




if __name__ == '__main__':
    file_birams = "./data/bigrams.csv"
    file_trigrams = "./data/trigrams.csv"
    file_quadrigrams = "./data/quadrigrams.csv"
    file_pentagrams = "./data/pentagrams.csv"
    file_unigrams = "./data/unigrams.csv"
    unigrams = UnigramsParser(file_unigrams)
    bigrams = BigramsParser(file_birams, file_trigrams)
    quadrigrams = QuadrigramsParser(file_quadrigrams, file_pentagrams)
